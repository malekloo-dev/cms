</section>

@yield('ckeditor')
@yield('footer')
</body>
</html>

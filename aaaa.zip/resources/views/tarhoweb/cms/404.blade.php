@extends(@env('TEMPLATE_NAME').'.App')
@section('Content')


<section class="breadcrumb">
    <div class="flex one  ">
        <div class="p-0">

  not found

        </div>
    </div>
</section>


@endsection

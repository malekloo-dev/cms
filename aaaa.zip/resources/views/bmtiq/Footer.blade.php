</div>

<!-- FOOTER -->
<footer id="t3-footer" class="wrap t3-footer">

    <div class="wrap t3-sl t3-sl-footer ">
        <div class="container">
            <div class="row">


                <div class="copyright col-sm-9">
                    <span>Copyright</span>
                    <span class="copy">©</span>
                    <span class="year">2020</span>
                    <span class="siteName"></span>
                    <span class="rights">All rights reserved </span>

                </div>

                <div class="moduletable   col-sm-3">
                    <div class="module_container">
                        <ul class="nav menu social-menu">
                            <li class="item-148"><a href="#" title="Facebook" class="fa fa-facebook"></a></li>
                            <li class="item-150"><a href="#" title="Twitter" class="fa fa-twitter"></a></li>
                            <li class="item-149"><a href="#" title="Google+" class="fa fa-google-plus"></a></li>
                            <li class="item-152"><a href="#" title="Skype" class="fa fa-skype"></a></li>
                        </ul>
                    </div>
                </div>


            </div>
        </div>
    </div>


</footer>
<!-- //FOOTER -->
</div>

<div id="back-top">
<a href="#"><span></span></a>
</div>


@yield('footer')
</body>

</html>

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WMS_INVENTORY extends Model
{
    protected $table = 'WMS_INVENTORY';



}

</section>
{{--<footer>
    <!-- section footer -->
    <a rel="to-top" href="#">
        <i class="fa fa-arrow-up"></i>
    </a>

    <p class="text-left no-padding">&copy; 2019 Abatalk.</p>
</footer>--}}
        @yield('ckeditor');
</body>
</html>
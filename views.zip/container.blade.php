<div class="page-title">
    <h1 class="text-white no-margin">Dashboard</h1>
</div>
<div class="content-body">
    <div class="row">
        <div class="col-xs-4 col-sm-4 col-md-3">
            <div class="mat-card mat-elevation-z3">
                <div class="mat-card-title">
                    Runing Campaigns
                </div>

                <div class="mat-content">
                    <span class="number-holder text-success">1</span>
                </div>
            </div>
        </div>
        <div class="col-xs-4 col-sm-4 col-md-3">
            <div class="mat-card mat-elevation-z3">
                <div class="mat-card-title">
                    Finished Campaigns
                </div>

                <div class="mat-content">
                    <span class="number-holder text-danger">0</span>
                </div>
            </div>
        </div>
        <div class="col-xs-4 col-sm-4 col-md-3">
            <div class="mat-card mat-elevation-z3">
                <div class="mat-card-title">
                    Number of sent email
                </div>

                <div class="mat-content">
                    <span class="number-holder text-success">1</span>
                </div>
            </div>
        </div>
        <div class="col-xs-4 col-sm-4 col-md-3">
            <div class="mat-card mat-elevation-z3">
                <div class="mat-card-title">
                    Number of email in queue
                </div>

                <div class="mat-content">
                    <span class="number-holder text-danger">25</span>
                </div>
            </div>
        </div>
    </div>
</div>
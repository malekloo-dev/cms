<section class="wide" id="footer">
    <div class="container">
        <div class="flex grow one two-600 four-900">
            <div class="social-network">
                {{--<div>شبکه های اجتماعی
                    <a href=""><img src="assets/img/instagram.png"></a>
                    <a href=""><img src="assets/img/facebook.png"></a>
                    <a href=""><img src="assets/img/pintrest.png"></a>
                </div>--}}
                {{--<div>عضویت در خبر نامه
                    <form class="mt-05">
                        <div class="flex">
                            <input class="three-fourth" type="text" name="subscribe"
                                   placeholder="آدرس ایمیل خود را وارد نمایید">
                            <button class="fourth">ارسال</button>
                        </div>
                    </form>
                </div>--}}
            </div>
            <div>
                {{--<div>راهنمای خرید</div>
                <ul>
                    <li><a href="">تعرفه آگهی</a></li>
                    <li><a href="">بدست آوردن امتیاز</a></li>
                    <li><a href="">شیوه های پرداخت</a></li>
                </ul>--}}
            </div>
            <div class="half">
                <div>ساخت سوئیچ-ساخت ریموت</div>
                <div>
                    ریموت یدک در زمینه ساخت سوئیچ و ریموت، کددهی ، تعریف و پروگرام ریموت خودرو، سوئیچ یدک  ، تراش تیغه و کلید و باز کردن درب خودرو برای انواع مدل خودرو مازراتی ، پورشه ، بنز ، بی ام و ، تویوتا ، کیا ، هیوندا ، رنو ، مزدا ،نیسان ، ام وی ام ، پژو ، لکسوس و غیره فعال می باشد.
                </div>
            </div>
        </div>
    </div>
</section>

</body>
</html>
@include('cms.Head')
@include('cms.Nav')
@yield('Content')
@include('cms.Footer')
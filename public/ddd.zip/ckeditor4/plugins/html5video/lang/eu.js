CKEDITOR.plugins.setLang( 'html5video', 'eu', {
    button: 'Txertatu HTML5 bideoa',
    title: 'HTML5 bideoa',
    infoLabel: 'Bideoaren informazioa',
    allowed: 'Baimendutako fitxategi luzapenak: MP4, WebM, Ogv',
    urlMissing: 'Bideoaren URLak ezin du hutsik egon.',
    videoProperties: 'Bideoaren propietateak',
    upload: 'Kargatu',
    btnUpload: 'Bidali zerbitzarira',
    advanced: 'Aurreratua',
    autoplay: 'Automatikoki erreproduzitu?',
    allowdownload: 'Allow download?',
    advisorytitle: 'Advisory title',
    yes: 'Bai',
    no: 'Ez',
    controls: 'Erakutsi kontrolak?'
} );

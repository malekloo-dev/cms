CKEDITOR.plugins.setLang( 'spacingsliders', 'ko', {
	title: '행간 및 자간',
	labels: {
		lineheight: '줄 간격',
		letterspacing: '글자 간격'
	}
} );
